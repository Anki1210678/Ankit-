import { useState } from "react";
import jsPDF from "jspdf";
import "jspdf-autotable";

export default function ResumeBuilder() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    education: "",
    experience: "",
    skills: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text("Resume", 105, 20, null, null, "center");

    doc.setFontSize(12);
    doc.text(`Name: ${formData.name}`, 20, 40);
    doc.text(`Email: ${formData.email}`, 20, 50);
    doc.text(`Phone: ${formData.phone}`, 20, 60);

    doc.text("Education:", 20, 80);
    doc.text(formData.education, 30, 90);

    doc.text("Experience:", 20, 110);
    doc.text(formData.experience, 30, 120);

    doc.text("Skills:", 20, 140);
    doc.text(formData.skills, 30, 150);

    doc.save("resume.pdf");
  };

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <h1 className="text-4xl font-bold mb-6 text-center">Resume Generator</h1>

      <div className="grid gap-6 bg-white p-6 rounded-xl shadow-md">
        {Object.keys(formData).map((field) => (
          <div key={field}>
            <label className="block font-semibold capitalize mb-1">{field}</label>
            <textarea
              name={field}
              value={formData[field]}
              onChange={handleChange}
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={field === "education" || field === "experience" || field === "skills" ? 3 : 1}
            />
          </div>
        ))}
        <button
          onClick={generatePDF}
          className="bg-gradient-to-r from-blue-600 to-blue-800 text-white font-semibold px-6 py-3 rounded-lg hover:from-blue-700 hover:to-blue-900 transition"
        >
          Download Resume PDF
        </button>
      </div>

      <div className="mt-10 p-6 bg-gray-100 rounded-xl shadow-inner">
        <h2 className="text-2xl font-bold mb-4">Live Preview</h2>
        <div className="space-y-2">
          <p><strong>Name:</strong> {formData.name}</p>
          <p><strong>Email:</strong> {formData.email}</p>
          <p><strong>Phone:</strong> {formData.phone}</p>
          <p><strong>Education:</strong> {formData.education}</p>
          <p><strong>Experience:</strong> {formData.experience}</p>
          <p><strong>Skills:</strong> {formData.skills}</p>
        </div>
      </div>
    </div>
  );
}
